﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ZestawZadan2.NewFolder1
{
    public partial class Zadanie1 : Window
    {
        public Zadanie1()
        {
            InitializeComponent();
        }

        private void DivideButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double number1 = Convert.ToDouble(Number1TextBox.Text);
                double number2 = Convert.ToDouble(Number2TextBox.Text);

                if (number2 == 0)
                {
                    throw new DivideByZeroException();
                }

                double result = number1 / number2;
                ResultTextBlock.Text = $"Result: {result}";
            }
            catch (DivideByZeroException)
            {
                ResultTextBlock.Text = "Error: Cannot divide by zero.";
                LogError("Division by zero attempted.");
            }
            catch (Exception ex)
            {
                ResultTextBlock.Text = "Error: Invalid input.";
                LogError($"Invalid input: {ex.Message}");
            }
        }

        private void LogError(string message)
        {
            if (!EventLog.SourceExists("Zadanie1App"))
            {
                EventLog.CreateEventSource("Zadanie1App", "Application");
            }
            EventLog.WriteEntry("Zadanie1App", message, EventLogEntryType.Error);
        }

        private void ShowErrorsButton_Click(object sender, RoutedEventArgs e)
        {
            ErrorListBox.Items.Clear();
            EventLog eventLog = new EventLog("Application");
            var logEntries = eventLog.Entries.Cast<EventLogEntry>().Where(entry => entry.Source == "Zadanie1App").ToList();
            foreach (var entry in logEntries)
            {
                ErrorListBox.Items.Add($"{entry.TimeGenerated}: {entry.Message}");
            }
        }
    }
}