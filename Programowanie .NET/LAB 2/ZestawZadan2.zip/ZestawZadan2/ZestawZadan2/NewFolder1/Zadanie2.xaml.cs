﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ZestawZadan2.NewFolder1
{
    public partial class Zadanie2 : Window
    {
        private Stopwatch stopwatch;

        public Zadanie2()
        {
            stopwatch = Stopwatch.StartNew();
            InitializeComponent();
            stopwatch.Stop();

            long startupTime = stopwatch.ElapsedMilliseconds;

            if (startupTime > 100)
            {
                LogWarning($"Application startup time: {startupTime}ms");
            }

            StartupTimeTextBlock.Text = $"Startup time: {startupTime}ms";
        }

        private void LogWarning(string message)
        {
            if (!EventLog.SourceExists("Zadanie2App"))
            {
                EventLog.CreateEventSource("Zadanie2App", "Application");
            }
            EventLog.WriteEntry("Zadanie2App", message, EventLogEntryType.Warning);
        }

        private void ShowLogButton_Click(object sender, RoutedEventArgs e)
        {
            LogListBox.Items.Clear();
            EventLog eventLog = new EventLog("Application");
            var logEntries = eventLog.Entries.Cast<EventLogEntry>().Where(entry => entry.Source == "Zadanie2App").ToList();
            foreach (var entry in logEntries)
            {
                LogListBox.Items.Add($"{entry.TimeGenerated}: {entry.Message}");
            }
        }
    }
}