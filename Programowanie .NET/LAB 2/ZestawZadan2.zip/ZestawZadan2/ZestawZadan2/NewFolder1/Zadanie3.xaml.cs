﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ZestawZadan2.NewFolder1
{
    public partial class Zadanie3 : Window
    {
        private Timer _timer;
        private PerformanceCounter _cpuCounter;
        private PerformanceCounter _memoryCounter;
        private const string LogFilePath = "system_monitor_log.txt";

        public Zadanie3()
        {
            InitializeComponent();
            _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            _memoryCounter = new PerformanceCounter("Memory", "Available MBytes");
        }

        private void StartMonitoringButton_Click(object sender, RoutedEventArgs e)
        {
            _timer = new Timer(1000); // Co 1 sekundę
            _timer.Elapsed += MonitorSystemResources;
            _timer.Start();
            MonitoringStatusTextBlock.Text = "Monitoring started.";
        }

        private void MonitorSystemResources(object sender, ElapsedEventArgs e)
        {
            float cpuUsage = _cpuCounter.NextValue();
            float availableMemory = _memoryCounter.NextValue();

            // Monitorowanie użycia procesora
            if (cpuUsage > 80)
            {
                LogWarning($"High CPU usage detected: {cpuUsage}%");
            }

            // Monitorowanie użycia pamięci
            if (availableMemory < 200) // Załóżmy, że próg to 200 MB
            {
                LogWarning($"Low available memory detected: {availableMemory}MB");
            }

            // Logowanie zasobów do pliku
            using (StreamWriter writer = new StreamWriter(LogFilePath, true))
            {
                writer.WriteLine($"Timestamp: {DateTime.Now}, CPU Usage: {cpuUsage}%, Available Memory: {availableMemory}MB");
            }
        }

        private void LogWarning(string message)
        {
            if (!EventLog.SourceExists("Zadanie3App"))
            {
                EventLog.CreateEventSource("Zadanie3App", "Application");
            }
            EventLog.WriteEntry("Zadanie3App", message, EventLogEntryType.Warning);
        }

        private void ShowLogButton_Click(object sender, RoutedEventArgs e)
        {
            LogListBox.Items.Clear();
            if (File.Exists(LogFilePath))
            {
                var lines = File.ReadAllLines(LogFilePath);
                foreach (var line in lines)
                {
                    LogListBox.Items.Add(line);
                }
            }
            else
            {
                LogListBox.Items.Add("Log file not found.");
            }
        }
    }
}