﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ZestawZadan2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OpenZadanie1(object sender, RoutedEventArgs e)
        {
            NewFolder1.Zadanie1 zadanie1Window = new NewFolder1.Zadanie1();
            zadanie1Window.Show();
        }

        private void OpenZadanie2(object sender, RoutedEventArgs e)
        {
            NewFolder1.Zadanie2 zadanie2Window = new NewFolder1.Zadanie2();
            zadanie2Window.Show();
        }

        private void OpenZadanie3(object sender, RoutedEventArgs e)
        {
            NewFolder1.Zadanie3 zadanie3Window = new NewFolder1.Zadanie3();
            zadanie3Window.Show();
        }
    }
}
